# Shadow Circuit

A mobile-first, real-time social deduction game for groups of friends.
Players join a room via a 6-character code, get assigned secret roles
(Citizens vs. Saboteurs), move between connected locations, complete
tasks, and try to identify (or hide as) the Saboteurs before time runs
out.

> **Note on originality**: Shadow Circuit is inspired by the general
> *genre* of social deduction party games. All names, visual design,
> map/node layouts, character designs, and copy in this project are
> original — no assets, text, or proprietary implementation details from
> any existing commercial game are used.

---

## Tech Stack

- **Frontend**: React 18 + Vite + TypeScript
- **State**: Zustand
- **Animation**: Framer Motion
- **Styling**: Tailwind CSS
- **Backend**: Firebase Realtime Database + Firebase Anonymous Auth +
  Firebase Hosting (optional)

---

## Project Status — Build Phases

This project is being built incrementally:

- [x] **Phase 1 — Architecture**: project scaffolding, types, Firebase
      schema & security rules, core stores, error handling, docs.
- [x] **Phase 2 — Lobby**: room create/join flow, character customization,
      ready system, host controls, bot auto-fill, tutorial, host migration.
- [x] **Phase 3 — Gameplay**: node map, movement, all 9 task minigames,
      eliminations, body reports, meetings & anonymous voting, win
      conditions, post-game/return-to-lobby flow, match-phase host
      migration, and a baseline deterministic bot driver (movement,
      tasks, kills, body reports, voting) so bot matches are fully
      playable.
- [ ] **Phase 3.5 — Multiplayer QA & Stress Testing**: reconnect/host-
      migration/race-condition checklist at 4/6/8/12 players before
      adding more bot intelligence. Three issues fixed during review:
      reconnect handlers now active during matches, eventLog pruning
      restored, and the meeting-creation race condition resolved via a
      transactional `claimMeeting` (only one meeting can ever be
      created; losing callers get a clean error and no body is lost).
      A dev-only QA devtools panel (`src/components/devtools/`,
      `import.meta.env.DEV`-gated and excluded from production builds)
      now enables most of the test matrix to be run solo via multi-tab
      identity + simulation tools — see `docs/QA_DEVTOOLS.md`. Remaining
      work is running that validation pass per `docs/TEST_CHECKLIST.md`.
- [ ] **Phase 4 — Bot Tuning**: difficulty-tuned suspicion/alibi behavior,
      richer bot decision-making beyond the Phase 3 baseline.
- [ ] **Phase 5 — Polish**: animations, debug mode, reconnect hardening,
      final QA pass.

---

## Quick Start

```bash
npm install
cp .env.example .env.local   # fill in your Firebase config — see docs/SETUP.md
npm run dev
```

Full setup instructions: [`docs/SETUP.md`](docs/SETUP.md)
Deployment instructions: [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md)
Database schema reference: [`docs/FIREBASE_SCHEMA.md`](docs/FIREBASE_SCHEMA.md)
Test checklist: [`docs/TEST_CHECKLIST.md`](docs/TEST_CHECKLIST.md)
QA devtools guide: [`docs/QA_DEVTOOLS.md`](docs/QA_DEVTOOLS.md)

---

## Project Structure

```
src/
  components/
    common/         # Shared UI: ErrorBoundary, LoadingScreen, Avatar, etc.
    lobby/          # Phase 2 — room setup, customization, settings
    match/          # Phase 3 — map view, task panel, action bar
    meeting/        # Phase 3 — discussion/voting/results overlay
    minigames/      # Phase 3 — 9 task minigames + launcher/shell
  hooks/            # Reusable hooks (connection status, game loop, etc.)
  lib/
    gameActions/    # Phase 3 — movement, eliminate, tasks, meetings,
                    # win conditions, host game loop, bot AI (bots.ts)
    minigames/      # Minigame registry (id -> metadata)
    ...             # Firebase init, map generator, presets, match service
  store/            # Zustand stores (auth, room, game, ui)
  types/            # Shared TypeScript types — keep in sync with schema docs
  utils/            # Pure helper functions (IDs, naming, etc.)
docs/               # Setup, deployment, schema, test checklist
database.rules.json  # Firebase Realtime Database security rules
firebase.json         # Firebase Hosting + DB config
```

---

## Core Game Rules (current settings ranges)

| Setting | Range | Default |
|---|---|---|
| Players | 4–12 | — |
| Saboteurs | 1–3 (scaled to player count) | auto |
| Map nodes | 6–12 (random layout each round) | 8 |
| Movement cooldown | 1s–6s by speed setting | 2.5s (Normal) |
| Kill cooldown | 10s–60s | 25s |
| Discussion duration | configurable | 45s |
| Voting duration | configurable | 30s |
| Minigames | 9 total (3 short / 3 medium / 3 long) | — |

Voting is **anonymous** (voter identities hidden, results shown after
voting ends) and **tie votes result in no ejection**. Players vote by
tapping another player's avatar. Chat is text-only.

---

## Architecture Notes

- **Server-authoritative-ish via host client**: Since this stack has no
  Cloud Functions, the current room host's client runs the authoritative
  game loop (timers, role assignment, bot AI, win-condition checks), with
  Firebase security rules constraining what any client can write. Host
  migration ensures this continues if the host disconnects. See
  `docs/FIREBASE_SCHEMA.md` for details and known trust limitations.
- **Secret roles**: stored at a path readable only by the assigned
  player (`games/{code}/secrets/{uid}`), enforced by security rules.
- **Transactions**: all state mutations susceptible to races (movement,
  kills, votes, meeting creation, host migration) use
  `runTransaction`.
- **Reconnect & identity persistence**: Firebase Auth uses an explicit
  persistence chain (IndexedDB → localStorage → in-memory) so a player's
  anonymous UID survives reloads and fully closing/reopening Safari. The
  active room code is saved to `localStorage` (not sessionStorage, which
  Safari clears on full close) and refreshed periodically while in a
  room. On launch, the app auto-resubscribes to the saved room and
  restores the player's `connected` status. `onDisconnect()` handlers are
  re-registered on every reconnect (`useReconnectHandlers`) since they're
  tied to the underlying socket connection. If a player's local identity
  is lost entirely (e.g. site data cleared) but the room still exists,
  they're offered a one-tap "rejoin as new player" flow instead of being
  stuck.

---

## License

This is a learning/demo project. No license has been chosen yet —
add one appropriate to your intended use before distributing.
