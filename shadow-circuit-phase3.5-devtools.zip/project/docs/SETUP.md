# Setup Guide

This guide covers local development setup and Firebase configuration.
Per project decisions, **Realtime Database and Anonymous Authentication
are assumed to already be enabled** on your Firebase project — this
guide still documents how to verify/enable them in case you're setting
up a fresh project.

## 1. Prerequisites

- Node.js 18+ and npm
- A Firebase project with:
  - **Realtime Database** enabled (not Firestore)
  - **Authentication → Sign-in method → Anonymous** enabled
- Firebase CLI (`npm install -g firebase-tools`) for deployment

## 2. Verify Firebase project settings

1. Go to the [Firebase Console](https://console.firebase.google.com/) →
   select your project.
2. **Authentication → Sign-in method** → confirm "Anonymous" is enabled.
   If not: click it, toggle "Enable", save.
3. **Realtime Database** → confirm a database instance exists. If not,
   create one (choose a region close to your players).
4. Note your **Database URL** (looks like
   `https://<project-id>-default-rtdb.<region>.firebasedatabase.app` or
   `https://<project-id>-default-rtdb.firebaseio.com`).

## 3. Get your Firebase web config

**Project Settings → General → Your apps** → if no web app exists, click
"Add app" → Web (`</>`) → register (no need for Firebase Hosting setup at
this step). Copy the config object shown — you'll need each value for
the next step.

## 4. Configure environment variables

```bash
cp .env.example .env.local
```

Edit `.env.local` and fill in every `VITE_FIREBASE_*` value from step 3,
plus `VITE_FIREBASE_DATABASE_URL` from step 2. **Do not commit
`.env.local`** (it's gitignored).

## 5. Install dependencies

```bash
npm install
```

## 6. Run locally

```bash
npm run dev
```

Open the printed local URL. For testing on an actual iPhone over your
LAN, Vite's `--host` flag (already enabled via `server.host: true` in
`vite.config.ts`) lets you visit `http://<your-computer-ip>:5173` from
your phone's Safari, as long as both devices are on the same network.

## 7. Deploy Realtime Database security rules

```bash
firebase login
firebase use --add        # select your project, alias it "default"
firebase deploy --only database
```

This pushes `database.rules.json` to your project. **Do this before
testing multiplayer features** — without rules deployed, all reads/writes
will be denied by Firebase's default-deny rules.

## 8. Building for production

```bash
npm run build
```

Output goes to `dist/`. See `docs/DEPLOYMENT.md` for hosting-specific
steps (GitHub Pages and/or Firebase Hosting).

## 9. Troubleshooting

- **"Missing required config values" in console**: `.env.local` is
  missing or has empty values. Re-check step 4.
- **PERMISSION_DENIED errors**: rules not deployed (step 7), or you're
  testing an operation not yet covered by the current phase's rules.
- **Anonymous auth fails immediately**: Anonymous sign-in not enabled
  (step 2.2), or your Firebase project has App Check enforcement enabled
  for Authentication (not covered by this setup — disable App Check
  enforcement for Auth during development if you've enabled it).
- **Stuck on "Connecting…"**: check `VITE_FIREBASE_DATABASE_URL` is
  correct — a wrong region/URL will hang `.info/connected` indefinitely.
