import { useState } from 'react';
import { useAuthStore } from '@/store/authStore';
import { useRoomStore } from '@/store/roomStore';
import { useGameStore } from '@/store/gameStore';
import { fetchRawGameState } from '@/lib/devtools/simulationActions';

type View = 'room' | 'game' | 'player';

/**
 * State tab: raw JSON dumps of room state, game state, and this tab's
 * player record — for spotting unexpected/missing fields, stale data,
 * or schema drift. The "room"/"game" views reflect the live
 * `useRoomStore`/`useGameStore` subscriptions (same data the rest of the
 * app uses); a "one-shot refresh" button on the game view does a fresh
 * server read for comparison (confirms the live subscription isn't
 * stuck/stale).
 */
export default function DevStateInspectorSection() {
  const [view, setView] = useState<View>('game');
  const uid = useAuthStore((s) => s.uid);
  const { room, roomCode } = useRoomStore();
  const { game } = useGameStore();
  const [rawGame, setRawGame] = useState<unknown>(null);
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    if (!roomCode) return;
    setRefreshing(true);
    try {
      setRawGame(await fetchRawGameState(roomCode));
    } finally {
      setRefreshing(false);
    }
  };

  const player = game && uid ? game.players[uid] : null;

  return (
    <div className="space-y-3">
      <div className="flex gap-1.5">
        {(['room', 'game', 'player'] as View[]).map((v) => (
          <button
            key={v}
            type="button"
            onClick={() => setView(v)}
            className={[
              'rounded-full px-3 py-1 text-[11px] font-medium border capitalize',
              view === v ? 'bg-warn text-ink-950 border-warn' : 'bg-ink-800 text-white/60 border-ink-700',
            ].join(' ')}
          >
            {v}
          </button>
        ))}
      </div>

      {view === 'room' && <JsonView data={room} empty="Not in a room." />}

      {view === 'game' && (
        <div className="space-y-2">
          <span className="text-white/40">Live subscription (useGameStore)</span>
          <JsonView data={game} empty="No active game." />

          <button
            type="button"
            onClick={handleRefresh}
            disabled={!roomCode || refreshing}
            className="w-full rounded-lg bg-ink-800 border border-ink-700 text-white/90 px-3 py-2 active:bg-ink-700 disabled:opacity-40"
          >
            {refreshing ? 'Refreshing…' : 'One-shot refresh from server'}
          </button>
          {rawGame !== null && (
            <>
              <span className="text-white/40">One-shot read result</span>
              <JsonView data={rawGame} empty="—" />
            </>
          )}
        </div>
      )}

      {view === 'player' && <JsonView data={player} empty="Not an active player in this match." />}
    </div>
  );
}

function JsonView({ data, empty }: { data: unknown; empty: string }) {
  if (data === null || data === undefined) {
    return <p className="text-white/30">{empty}</p>;
  }
  return (
    <pre className="bg-ink-900 border border-ink-700 rounded-lg p-2 overflow-x-auto text-[11px] text-white/80 leading-relaxed max-h-[40vh]">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}
