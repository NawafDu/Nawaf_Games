import { useDevToolsStore, type LatencyPreset } from '@/lib/devtools/devToolsStore';

const PRESETS: LatencyPreset[] = [0, 100, 250, 500, 1000];

/**
 * Latency tab: artificially delays this tab's gameplay actions (move,
 * eliminate, report body, call meeting, cast vote, complete task) by the
 * selected amount before sending them — see `withDevLatency` in
 * devToolsStore.ts and its call sites in MatchScreen/ActionBar/
 * MeetingOverlay/MinigameLauncher.
 *
 * Only affects THIS TAB. Useful for testing how the UI behaves when this
 * tab's actions are slow relative to other tabs' — e.g. does a delayed
 * vote still land before the voting phase ends? Does a delayed move
 * still get rejected correctly if the cooldown changed in the meantime?
 */
export default function DevLatencySection() {
  const latencyMs = useDevToolsStore((s) => s.latencyMs);
  const setLatency = useDevToolsStore((s) => s.setLatency);

  return (
    <div className="space-y-4">
      <section className="bg-ink-900 border border-ink-700 rounded-xl p-3 space-y-3">
        <h3 className="font-display text-warn">Action Latency (this tab)</h3>
        <p className="text-white/50 leading-relaxed">
          Adds an artificial delay before this tab's movement,
          elimination, body report, emergency meeting, vote, and task
          completion calls reach the server. Does not affect reads (you
          still see other tabs' updates instantly).
        </p>
        <div className="grid grid-cols-5 gap-2">
          {PRESETS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setLatency(preset)}
              className={[
                'rounded-lg py-2 text-center font-medium transition-colors',
                latencyMs === preset ? 'bg-warn text-ink-950' : 'bg-ink-800 text-white/70 border border-ink-700',
              ].join(' ')}
            >
              {preset === 0 ? 'Off' : `${preset}ms`}
            </button>
          ))}
        </div>
        {latencyMs > 0 && (
          <p className="text-warn">Active: every gameplay action from this tab is delayed by {latencyMs}ms.</p>
        )}
      </section>
    </div>
  );
}
